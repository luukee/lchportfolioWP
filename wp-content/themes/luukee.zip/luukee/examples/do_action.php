<?php

    // Single arg
    do_action( $tag, $arg );

    // Multiple args
    do_action( $tag, $arg_a, $arg_b, $etc );

    // Multiple args
    do_action_ref_array( $tag, $args );


?>