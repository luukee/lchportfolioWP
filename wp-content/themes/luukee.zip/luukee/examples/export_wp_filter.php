<pre>
<?php var_export( $wp_filter ); ?>
</pre>