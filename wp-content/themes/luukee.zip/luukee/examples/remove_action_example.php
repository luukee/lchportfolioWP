<?php 

remove_action( 'wp_enqueue_scripts', 'add_google_font' );

?>