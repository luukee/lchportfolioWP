<?php
/**
 * The template for displaying the footer.
 */
?>

<!-- <div id="footer"><p class="body-background">© <?php //echo date('Y'); ?> Luke Carl Hartman</p></div> -->


<?php wp_footer(); ?>

</body>
</html>

