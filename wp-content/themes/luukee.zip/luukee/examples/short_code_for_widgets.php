<?php
 
// Add the ability to use shortcodes in Widgets
add_filter( 'widget_text', 'do_shortcode' );

?>