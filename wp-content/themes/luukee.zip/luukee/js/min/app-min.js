"use strict";$(document).foundation();
//# sourceMappingURL=./app-min.js.map